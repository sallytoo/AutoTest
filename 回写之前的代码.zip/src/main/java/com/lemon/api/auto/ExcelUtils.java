package com.lemon.api.auto;

import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcelUtils {

	public static void readExcel(String excelPath) throws EncryptedDocumentException, InvalidFormatException, IOException {
		InputStream inp = ExcelUtils.class.getResourceAsStream(excelPath);
		//获得工作簿对象
		Workbook workbook = WorkbookFactory.create(inp);
		//获得第一个sheet
		Sheet sheet=workbook.getSheetAt(0);
		//获取第一行
		Row row = sheet.getRow(0);
		//获取第一列
		Cell cell = row.getCell(0);
		String value = cell.getStringCellValue();
		System.out.println(value);
			
	}
	public static void main(String[] args) throws EncryptedDocumentException, InvalidFormatException, IOException {
		readExcel("/api.xlsx");
	}

}
