package com.lemon.api.auto.utils;

import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.lemon.api.auto.pojo.ApiInfo;

public class ExcelUtils {
	/**
	 * 将所有的测试用例写在一个excel中,读取该测试用例
	 * 
	 * @param excelPath
	 *            excel的路径
	 * @param sheetNum
	 *            sheet编号，从1开始，传1表示第一个sheet，即索引为0的sheet
	 * @return
	 */

	public static List<Object> readAllCaseExcel(String excelPath, int sheetNum, Class clazz) {
		List<Object> objoList = null;
		try {
			InputStream inp = ExcelUtils.class.getResourceAsStream(excelPath);
			// 获得工作薄对象
			Workbook workbook = WorkbookFactory.create(inp);
			// 获得第一个sheet
			Sheet sheet = workbook.getSheetAt(sheetNum - 1);
			// 通过遍历拿到所有的行->通过遍历拿到每一行的列
			// 获得最后的行号(行的索引，从0开始)
			int lastRowNum = sheet.getLastRowNum();

			// 获得第一行
			Row fistrow = sheet.getRow(0);
			// 获得最大的列数(从1开始)
			int lastCellNum = fistrow.getLastCellNum();
			// 创建一个数组，保存表头信息
			String[] columnArray = new String[lastCellNum];
			// 循环遍历第一行，获得表头
			for (int k = 0; k < lastCellNum; k++) {
				// 若存在值为空，则设置该值为空
				Cell cell = fistrow.getCell(k, MissingCellPolicy.CREATE_NULL_AS_BLANK);
				// 设置列的类型
				cell.setCellType(CellType.STRING);
				// 获得该列的值
				String columnName = cell.getStringCellValue();
				columnArray[k] = columnName;
			}

			// 创建一个Object类型的二维数组，保存从excel解析出来的行列数据
			objoList = new ArrayList<>();
			for (int i = 1; i <= lastRowNum; i++) {
				// 获得索引对应的行
				Row row = sheet.getRow(i);

				// 通过字节码对象实例化一个对象
				Object obj = clazz.newInstance();
				for (int j = 0; j < lastCellNum; j++) {
					// 若存在值为空，则设置该值为空
					Cell cell = row.getCell(j, MissingCellPolicy.CREATE_NULL_AS_BLANK);
					// 设置列的类型
					cell.setCellType(CellType.STRING);
					// 获得该列的值
					String cellValue = cell.getStringCellValue();
					// 得到setter方法的名称
					String setMethodName = "set" + columnArray[j].substring(0, columnArray[j].indexOf("("));
					// 得到setter方法
					Method setMethod = clazz.getMethod(setMethodName, String.class);
					// 反射调用该方法
					setMethod.invoke(obj, cellValue);

				}
				// 每遍历一行，要把改行对应的以为数组添加进去
				objoList.add(obj);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return objoList;
	}

	@Deprecated // 过期了
	public static Object[][] readAllCaseExcel(String excelPath, int sheetNum) {
		Object[][] datas = null;
		try {
			InputStream inp = ExcelUtils.class.getResourceAsStream(excelPath);
			// 获得工作薄对象
			Workbook workbook = WorkbookFactory.create(inp);
			// 获得第一个sheet
			Sheet sheet = workbook.getSheetAt(sheetNum - 1);
			// 通过遍历拿到所有的行->通过遍历拿到每一行的列
			// 获得最后的行号
			// 获得最后的行号(行的索引，从0开始)
			int lastRowNum = sheet.getLastRowNum();

			// 获得第一行
			Row fistrow = sheet.getRow(0);
			// 获得最大的列数(从1开始)
			int lastCellNum = fistrow.getLastCellNum();

			// 创建一个Object类型的二维数组，保存从excel解析出来的行列数据
			datas = new Object[lastRowNum][];
			for (int i = 1; i <= lastRowNum; i++) {
				// 获得索引对应的行
				Row row = sheet.getRow(i);
				// 创建一个一维数组，保存该行的所有列信息
				Object[] cellArry = new Object[lastCellNum];
				for (int j = 0; j < lastCellNum; j++) {
					// 若存在值为空，则设置该值为空
					Cell cell = row.getCell(j, MissingCellPolicy.CREATE_NULL_AS_BLANK);
					// 设置列的类型
					cell.setCellType(CellType.STRING);
					// 获得该列的值
					String cellValue = cell.getStringCellValue();
					cellArry[j] = cellValue;

				}
				// 每遍历一行，要把改行对应的以为数组添加进去
				datas[i - 1] = cellArry;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return datas;
	}

	/**
	 * 1个excel中保存一个类型的测试用例
	 * 
	 * @param excelPath
	 *            excel的路径
	 * @return
	 */
	@Deprecated
	public static Object[][] readExcel(String excelPath) {
		Object[][] datas = null;
		try {
			InputStream inp = ExcelUtils.class.getResourceAsStream(excelPath);
			// 获得工作薄对象
			Workbook workbook = WorkbookFactory.create(inp);
			// 获得第一个sheet
			Sheet sheet = workbook.getSheetAt(0);
			// 通过遍历拿到所有的行->通过遍历拿到每一行的列
			// 获得最后的行号
			// 获得最后的行号(行的索引，从0开始)
			int lastRowNum = sheet.getLastRowNum();

			// 获得第一行
			Row fistrow = sheet.getRow(0);
			// 获得最大的列数(从1开始)
			int lastCellNum = fistrow.getLastCellNum();

			// 创建一个Object类型的二维数组，保存从excel解析出来的行列数据
			datas = new Object[lastRowNum][];
			for (int i = 1; i <= lastRowNum; i++) {
				// 获得索引对应的行
				Row row = sheet.getRow(i);

				// 创建一个一维数组，保存改行的所有列信息
				Object[] cellDatas = new Object[lastCellNum];
				for (int j = 0; j < lastCellNum; j++) {
					// 若存在值为空，则设置该值为空
					Cell cell = row.getCell(j, MissingCellPolicy.CREATE_NULL_AS_BLANK);
					// 设置列的类型
					cell.setCellType(CellType.STRING);
					// 获得该列的值
					String cellValue = cell.getStringCellValue();
					cellDatas[j] = cellValue;
				}
				// 每遍历一行，要把改行对应的以为数组添加进去
				datas[i - 1] = cellDatas;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return datas;
	}

	public static void main(String[] args) {
		List<Object> listMap = readAllCaseExcel("/api_test_case_01.xlsx", 1, ApiInfo.class);// url
		for (Object obj : listMap) {
			ApiInfo apiInfo = (ApiInfo) obj;
			System.out.println(obj);
		}

		

	}

}
