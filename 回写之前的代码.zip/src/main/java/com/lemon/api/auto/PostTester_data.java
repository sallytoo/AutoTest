package com.lemon.api.auto;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class PostTester_data {
	@DataProvider
	public Object[][] datas(){
		//硬编码--》数据分离--》xml、Excel、db,cvs
	Object[][] datas={
			{"18258442456","123456","tom1"},
			{"1822456","123456","tom2"},
			{"lomen2","123456","tom3"},
			{"18258442256","","tom1"},
			
	};
	//把耦合度高的代码提取出来，把需要解析的代码取出来
	return datas;	}
	@Test(dataProvider="datas")
	public void postTest(String mobilephone,String pwd,String regname) throws Exception{
		//URI的参数不直接写到uri，可以参数拼接起来，这样有些特殊字符还可以显示
//		String uri = "http://127.0.0.1:8080/futureloan/mvc/api/member/register?mobilephone=18258442458&pwd=123456";	
//		
		String uri = "http://127.0.0.1:8080/futureloan/mvc/api/member/register";
		Map<String,String > paramsMap = new HashMap<>();
		paramsMap.put("mobilephone", mobilephone);
		paramsMap.put("pwd", pwd);
		paramsMap.put("regname",regname);
		
		String result = HttpUtils.post(uri, paramsMap);
		System.out.println(result);
		
	}

	}



