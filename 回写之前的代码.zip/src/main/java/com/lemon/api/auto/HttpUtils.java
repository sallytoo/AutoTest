package com.lemon.api.auto;

import java.io.IOException;
import java.io.PushbackReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.jar.Attributes.Name;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.ParseException;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

public class HttpUtils {
	/**
	 * 写一个方法，发get请求
	 * 登录接口，注册接口，充值接口，提现接口
	 * 1：URL会变
	 * 2：参数会变
	 * @return
	 * @throws IOException 
	 * @throws ClientProtocolException 
	 */
	public static String get(String uri,Map<String,String > paramsMap){
		
		try {
			List<NameValuePair> parameters = null;
			if (paramsMap != null) {
				parameters = new ArrayList<>();
				//遍历map的所有键值对
				Set<String> keyset = paramsMap.keySet();
				for (String name : keyset) {
					String value = paramsMap.get(name);
					parameters.add(new BasicNameValuePair(name, value));
				
			}
				//编码后的参数列表
			String encodeparams=URLEncodedUtils.format(parameters, "utf-8");
			uri += ("?"+encodeparams);
			HttpGet httpGet = new HttpGet(uri);
			
			//创建一个Http发包客户端（http发包客户端具备这样的功能：浏览器、postman、jmeter）
			CloseableHttpClient httpClient = HttpClients.createDefault();
			//发数据包---》获得响应
			CloseableHttpResponse httpResponse =httpClient.execute(httpGet);
			//响应体
			HttpEntity respentity = httpResponse.getEntity();
			return  EntityUtils.toString(respentity);
		}}catch (Exception e) {
			e.printStackTrace();
		} 
		return "";
		
	}

	public static String post(String uri,Map<String , String > paramsMap) {
		//生成一个post请求
		try {
			HttpPost post = new HttpPost(uri);
			List<NameValuePair> parameters = new ArrayList<NameValuePair>();
			if(paramsMap !=null) {
				//遍历map的所有的键值对
			Set<String> keyset = paramsMap.keySet();
			for (String name : keyset) {
				String value = paramsMap.get(name);
				parameters.add(new BasicNameValuePair(name, value));
				
			}
			    //创建一个原生form表单的请求体
			UrlEncodedFormEntity entity = new UrlEncodedFormEntity(parameters);
			//设置post请求请求体
			post.setEntity(entity);
			}
			CloseableHttpClient httpClient = HttpClients.createDefault();
			CloseableHttpResponse response = httpClient.execute(post);
			HttpEntity respentity = response.getEntity();
			return EntityUtils.toString(respentity);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "";	
		} 
		
	}
}
