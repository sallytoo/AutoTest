package com.lemon.api.auto;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.testng.annotations.Test;

/*public class GetTester_bak {
	
	@Test
	public void getTest() throws Exception{
		//URI的参数不直接写到uri，可以参数拼接起来，这样有些特殊字符还可以显示
//		String uri = "http://127.0.0.1:8080/futureloan/mvc/api/member/register?mobilephone=18258442458&pwd=123456";	
//		
		String uri = "http://127.0.0.1:8080/futureloan/mvc/api/member/register";
		List<NameValuePair> parameters = new ArrayList<NameValuePair>();
		parameters.add(new BasicNameValuePair("mobilephone", ""));
		parameters.add(new BasicNameValuePair("pwd", "123456"));
		parameters.add(new BasicNameValuePair("regname", "tom666&sally"));
	String result = HttpUtils.get(uri, parameters);
		System.out.println(result);
		
	}

	@Test
	public void getTest1() throws Exception, Exception{
		//URI的参数不直接写到uri，可以参数拼接起来，这样有些特殊字符还可以显示
//		String uri = "http://127.0.0.1:8080/futureloan/mvc/api/member/register?mobilephone=18258442458&pwd=123456";	
//		
		String uri = "http://127.0.0.1:8080/futureloan/mvc/api/member/register";
		List<NameValuePair> parameters = new ArrayList<NameValuePair>();
		parameters.add(new BasicNameValuePair("mobilephone", "15077161543"));
		parameters.add(new BasicNameValuePair("pwd", "123456"));
		parameters.add(new BasicNameValuePair("regname", "tomniy"));
		String result = HttpUtils.get(uri, parameters);
		System.out.println(result);
		
	}

	@Test
	public void getTest2() throws Exception, Exception{
		//URI的参数不直接写到uri，可以参数拼接起来，这样有些特殊字符还可以显示
//		String uri = "http://127.0.0.1:8080/futureloan/mvc/api/member/register?mobilephone=18258442458&pwd=123456";	
//		
		String uri = "http://127.0.0.1:8080/futureloan/mvc/api/member/register";
		List<NameValuePair> parameters = new ArrayList<NameValuePair>();
		parameters.add(new BasicNameValuePair("mobilephone", "18258442431"));
		parameters.add(new BasicNameValuePair("pwd", "12356"));
		String result = HttpUtils.get(uri, parameters);
		System.out.println(result);
		
	}
	
	}
*/


