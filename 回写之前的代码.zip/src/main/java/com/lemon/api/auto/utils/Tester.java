package com.lemon.api.auto.utils;

import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;

import com.lemon.api.auto.pojo.ApiInfo;
import com.lemon.api.auto.pojo.Apidetail;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class Tester {

	public static List<Object> readExcel(String exPath,int sheetNum,Class clazz){
		List<Object> objList = null;
		InputStream inps = ExcelUtils.class.getResourceAsStream(exPath);
		try {
			Workbook workbook=WorkbookFactory.create(inps);//创建工作簿对象
			Sheet sheet = workbook.getSheetAt(sheetNum-1);//获得第一个sheet
			int lastrow = sheet.getLastRowNum();//获得最后一行的行号，索引从0开始
	
			Row firstrow = sheet.getRow(0);
			int lastCell = firstrow.getLastCellNum();//得到一行最大的列数
			String[] columnArray =new String[lastCell];//创建一个数组保存表头信息
			// 循环遍历第一行，获得表头
			for (int k=0;k < lastCell;k++) {
				Cell cell = firstrow.getCell(k, MissingCellPolicy.CREATE_NULL_AS_BLANK);// 若存在值为空，则设置该值为空
				cell.setCellType(CellType.STRING);// 设置列的类型
				String columnName = cell.getStringCellValue();// 获得该列的值
				columnArray[k]=columnName;
			}
		          objList= new ArrayList<>(); // 创建一个Object类型二维数组，保存从excel解析出来的行列数据
					for (int i = 0; i < lastrow; i++) {
						// 获得索引对应的行
						Row row = sheet.getRow(i);
						// 通过字节码对象实例化一个对象
						Object obj = clazz.newInstance();
						for (int j = 0; j < lastCell; j++) {
							Cell cell =row.getCell(i, MissingCellPolicy.CREATE_NULL_AS_BLANK);// 若存在值为空，则设置该值为空
							// 设置列的类型
							cell.setCellType(CellType.STRING);
							// 获得该列的值
							String cellValue = cell.getStringCellValue();
							// 得到setter方法的名称
							String setMethodName = "set"+columnArray[j].substring(0, columnArray[j].indexOf("("));
							// 得到setter方法
						Method setMethod = clazz.getMethod(setMethodName, String.class);
						setMethod.invoke(obj, cellValue);
						}
						//每遍历一行，要把改行对应的以为数组添加进去
						objList.add(obj);
					}

		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		return objList;
		
	}
	
	public static void main(String[] args) {

		/*
		 * Object[][] datas = readExcel("/api.xlsx"); for (Object[] objects :
		 * datas) { for (Object object : objects) { System.out.print(object +
		 * "   "); } System.out.println(); }
		 */
		List<Object> listMap = readExcel("/api_test_case_01.xlsx", 1, ApiInfo.class);// url
		for (Object obj : listMap) {
			ApiInfo apiInfo = (ApiInfo) obj;
			System.out.println(obj);
		}
	
	}
}
	
	
	
		

	


