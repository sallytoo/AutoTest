package com.lemon.api.auto;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.management.monitor.MonitorMBean;
import javax.print.attribute.standard.RequestingUserName;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.internal.junit.ArrayAsserts;

public class AutoTester4 {
	@DataProvider
	public Object[][] withdraw() {
		Object[][] datas = { 
				{ "18258442456", "200", "成功" },
				{ "15077160001", "200", "不存在" },
				{ "18258442456", "200.000", "不能超过两位" }, 
				{ "18258422456", "200.00", "不存在" },
				{ "1825842256", "200.00", "不正确" }, };
		return datas;

	}

	@Test(dataProvider = "withdraw")
	public void post(String mobilephone, String amount, String partialresult) throws Exception {
		String uri = "http://127.0.0.1:8080/futureloan/mvc/api/member/withdraw";
		HttpPost post = new HttpPost(uri);
		List<NameValuePair> parameters = new ArrayList<NameValuePair>();
		parameters.add(new BasicNameValuePair("mobilephone", mobilephone));
		parameters.add(new BasicNameValuePair("amount", amount));
		UrlEncodedFormEntity entity = new UrlEncodedFormEntity(parameters);
		post.setEntity(entity);
		CloseableHttpClient httpClient = HttpClients.createDefault();
		CloseableHttpResponse response = httpClient.execute(post);
		StatusLine line = response.getStatusLine();
		System.out.println(line.getStatusCode());

		Header[] headers = response.getAllHeaders();
		for (Header header : headers) {
			System.out.println("name:" + header.getName() + "value:" + header.getValue());

		}
		HttpEntity respentity = response.getEntity();
		String respResule = EntityUtils.toString(respentity);
		System.out.println(respResule);
		Assert.assertTrue(respResule.contains(partialresult));

	}

}
